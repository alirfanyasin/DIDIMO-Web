<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>DIDIMO - <?php echo $__env->yieldContent('title'); ?></title>

    
    <link rel="icon" href="/assets/img/logo-main.png">

    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    
    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
    
    <link rel="stylesheet" href="/assets/css/app.css" />
</head>

<body>

    
    <?php if (isset($component)) { $__componentOriginalf4613edb01d2718d9bf48627a0341a40 = $component; } ?>
<?php $component = App\View\Components\Navbar\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Navbar\Navbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf4613edb01d2718d9bf48627a0341a40)): ?>
<?php $component = $__componentOriginalf4613edb01d2718d9bf48627a0341a40; ?>
<?php unset($__componentOriginalf4613edb01d2718d9bf48627a0341a40); ?>
<?php endif; ?>
    

    
    <?php echo $__env->yieldContent('content'); ?>
    

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
    </script>


    <?php echo $__env->yieldPushContent('js-libraries'); ?>
</body>

</html>
<?php /**PATH C:\Users\Irfan Yasin\Documents\My-Program\Laravel\DIDIMO-Web\resources\views/layouts/app.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title', 'Kontrol Gula Darah Semakin Mudah'); ?>


<?php $__env->startSection('content'); ?>
    <section class="background-primary position-relative">
        <div class="grading-upground"></div>
        <div class="container">
            <div class="row">
                <div class="col d-flex">
                    <header class="align-items-center">
                        <h1 class="text-white">Artikel</h1>
                        <p class="text-white">Rekomendasi makanan dan pola hidup sehat</p>
                    </header>
                </div>
            </div>
        </div>
    </section>

    <section class="container" id="artikel-section">
        <div class="row">
            <div class="col-md-4 col-lg-3 col-sm-6 mb-4">
                <a href="">
                    <div class="card rounded-4 position-relative overflow-hidden">
                        <div class="grading-upgraound"></div>
                        <img src="<?php echo e(asset('assets/img/img-6.jpg')); ?>" class="card-img-top rounded-4" alt="...">
                        <div class="card-title position-absolute m-4" style="bottom: 0">
                            <div class="text-white">Menghindari makanan manis dengan hal-hal berikut . . .</div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 col-lg-3 col-sm-6 mb-4">
                <a href="">
                    <div class="card rounded-4 position-relative overflow-hidden">
                        <div class="grading-upgraound"></div>
                        <img src="<?php echo e(asset('assets/img/img-7.jpg')); ?>" class="card-img-top rounded-4" alt="...">
                        <div class="card-title position-absolute m-4" style="bottom: 0">
                            <div class="text-white">Makanan makanan yang manis tapi sehat untuk di konsumsi . . .</div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 col-lg-3 col-sm-6 mb-4">
                <a href="">
                    <div class="card rounded-4 position-relative overflow-hidden">
                        <div class="grading-upgraound"></div>
                        <img src="<?php echo e(asset('assets/img/img-8.jpeg')); ?>" class="card-img-top rounded-4" alt="...">
                        <div class="card-title position-absolute m-4" style="bottom: 0">
                            <div class="text-white">Menghindari makanan manis dengan hal-hal berikut . . .</div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 col-lg-3 col-sm-6 mb-4">
                <a href="">
                    <div class="card rounded-4 position-relative overflow-hidden">
                        <div class="grading-upgraound"></div>
                        <img src="<?php echo e(asset('assets/img/img-9.jpeg')); ?>" class="card-img-top rounded-4" alt="...">
                        <div class="card-title position-absolute m-4" style="bottom: 0">
                            <div class="text-white">Menghindari makanan manis dengan hal-hal berikut . . .</div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 col-lg-3 col-sm-6 mb-4">
                <a href="">
                    <div class="card rounded-4 position-relative overflow-hidden">
                        <div class="grading-upgraound"></div>
                        <img src="<?php echo e(asset('assets/img/img-2.jpeg')); ?>" class="card-img-top rounded-4" alt="...">
                        <div class="card-title position-absolute m-4" style="bottom: 0">
                            <div class="text-white">Menghindari makanan manis dengan hal-hal berikut . . .</div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 col-lg-3 col-sm-6 mb-4">
                <a href="" class=" h-100">
                    <div class="card rounded-4 position-relative overflow-hidden">
                        <div class="grading-upgraound"></div>
                        <img src="<?php echo e(asset('assets/img/img-3.png')); ?>" class="card-img-top rounded-4" alt="...">
                        <div class="card-title position-absolute m-4" style="bottom: 0">
                            <div class="text-white">Menghindari makanan manis dengan hal-hal berikut . . .</div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 col-lg-3 col-sm-6 mb-4">
                <a href="">
                    <div class="card rounded-4 position-relative overflow-hidden ">
                        <div class="grading-upgraound"></div>
                        <img src="<?php echo e(asset('assets/img/img-4.jpg')); ?>" class="card-img-top rounded-4" alt="...">
                        <div class="card-title position-absolute m-4" style="bottom: 0">
                            <div class="text-white">Menghindari makanan manis dengan hal-hal berikut . . .</div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </section>

    <?php if (isset($component)) { $__componentOriginale68e7da7fd72301c123612d1c24269bb = $component; } ?>
<?php $component = App\View\Components\Footer\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footer.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Footer\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale68e7da7fd72301c123612d1c24269bb)): ?>
<?php $component = $__componentOriginale68e7da7fd72301c123612d1c24269bb; ?>
<?php unset($__componentOriginale68e7da7fd72301c123612d1c24269bb); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Irfan Yasin\Documents\My-Program\Laravel\DIDIMO-Web\resources\views/artikel/index.blade.php ENDPATH**/ ?>
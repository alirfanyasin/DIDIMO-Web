<nav class="navbar navbar-expand-lg bg-transparent">
    <div class="container">
        <a class="navbar-brand" href="/">
            <img src="<?php echo e(asset('assets/img/logo-secondary.png')); ?>" width="120px" alt="logo-didimo" class="">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup"
            aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <?php if(auth()->guard()->guest()): ?>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="me-auto"></div>
                <div class="navbar-nav ml-auto">
                    <a class="nav-link mx-2 <?php echo e(Request::is('/') ? 'active' : ''); ?>" href="/">Beranda</a>
                    <a class="nav-link mx-2" href="#tentang-kami-section">Tentang Kami</a>
                    <a class="nav-link mx-2" href="#layanan-section">Layanan</a>
                    <a class="nav-link mx-2 <?php echo e(Request::is('artikel') ? 'active' : ''); ?>"
                        href="<?php echo e(route('artikel')); ?>">Artikel</a>
                    <a class="nav-link mx-2" href="#testimonial-section">Testimonial</a>
                    <a class="nav-link mx-2 btn btn-primary px-3" href="<?php echo e(route('login')); ?>">Masuk</a>
                </div>
            </div>
        <?php endif; ?>

        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="me-auto"></div>
                <div class="navbar-nav ml-auto">
                    <a class="nav-link mx-2 <?php echo e(Request::is('app/admin/dashboard') ? 'active' : ''); ?>"
                        href="/app/admin/dashboard">Dashboard</a>
                    <a class="nav-link mx-2 <?php echo e(Request::is('app/admin/pasien') ? 'active' : ''); ?>"
                        href="/app/admin/pasien">Pasien</a>
                    <a class="nav-link mx-2 <?php echo e(Request::is('app/admin/artikel') ? 'active' : ''); ?>"
                        href="/app/admin/artikel">Artikel</a>
                    <a class="nav-link mx-2 <?php echo e(Request::is('app/admin/konsultasi') ? 'active' : ''); ?>"
                        href="/app/admin/konsultasi">Konsultasi</a>
                    <form action="<?php echo e(route('logout')); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="nav-link mx-2 btn btn-primary px-3">Keluar</button>
                    </form>
                </div>
            </div>
        <?php endif; ?>

        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'user')): ?>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="me-auto"></div>
                <div class="navbar-nav ml-auto">
                    <a class="nav-link mx-2 <?php echo e(Request::is('app/dashboard') ? 'active' : ''); ?>"
                        href="/app/dahsboard">Dashboard</a>
                    <a class="nav-link mx-2" href="#">Cek up</a>
                    <a class="nav-link mx-2" href="#layanan-section">Konsultasi</a>
                    <a class="nav-link mx-2 <?php echo e(Request::is('artikel') ? 'active' : ''); ?>"
                        href="#artikel-section">Riwayat</a>
                    <form action="<?php echo e(route('logout')); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="nav-link mx-2 btn btn-primary px-3">Keluar</button>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </div>
</nav>
<?php /**PATH C:\Users\Irfan Yasin\Documents\My-Program\Laravel\DIDIMO-Web\resources\views/components/navbar/navbar.blade.php ENDPATH**/ ?>
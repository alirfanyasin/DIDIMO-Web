
<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
    <section class="" style="overflow-x: hidden" id="login-page">
        <div class="row">
            <div class="col-md-6">
                <div class="header px-5">
                    <img src="<?php echo e(asset('assets/img/logo-main.png')); ?>" class="mt-3 mx-auto d-block " width="100px">
                    <h1 class="fw-bold mx-5 mt-2 text-center mb-4" id="headerText"><span class="text-main">Selamat</span>
                        Datang</h1>
                    <?php if(session('message')): ?>
                        <div class="row d-flex justify-content-center m-0">
                            <div class="col-8">
                                <div class="alert <?php echo e(session('message') == 'success' ? 'alert-success' : 'alert-danger'); ?> alert-dismissible fade show"
                                    role="alert">
                                    <?php echo e(session('message') == 'success' ? 'Email berhasil terkirim' : 'Email tidak ditemukan'); ?>

                                    <button type="button" class="btn-close" data-bs-dismiss="alert"
                                        aria-label="Close"></button>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('send_email.forgot_password')); ?>" method="POST"
                        class="row d-flex justify-content-center">
                        <?php echo csrf_field(); ?>
                        <div class="col-md-8">
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Email</label>
                                <input type="email" name="email"
                                    class="border-main rounded-3 form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="forgot_password" placeholder="Masukkan Email" autofocus>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <button class="btn rounded-3 button-main w-100 text-white" type="submit">Kirim Email</button>
                        </div>
                    </form>

                </div>
            </div>
            <div class="col-md-6">
                <div class="bg-color" id="login-left">
                    <img src="<?php echo e(asset('assets/img/bgGlass.png')); ?>" style="width: 100vh; right: 0;">
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('js-libraries'); ?>
    <script>
        var password = document.getElementById('loginPass');
        var eye = document.getElementById('eye');
        var icon = document.getElementById('icon');


        eye.addEventListener('click', () => {
            if (password.type == 'password') {
                password.type = 'text';
                icon.setAttribute('icon', 'iconamoon:eye-off')
            } else {
                password.type = 'password';
                icon.setAttribute('icon', 'uiw:eye-o')
            }
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Irfan Yasin\Documents\My-Program\Laravel\DIDIMO-Web\resources\views/auth/forgot_password.blade.php ENDPATH**/ ?>